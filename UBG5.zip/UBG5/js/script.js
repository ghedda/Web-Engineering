// Task 1: multiplyNumeric function
function multiplyNumeric(obj) {
    // Iterate over all properties in the object
    for (let key in obj) {
        // Check if the property value is a number
        if (typeof obj[key] === 'number') {
            // Double the value
            obj[key] *= 2;
        }
    }
    // Print the modified object
    console.log(obj);
}

// Define the object to be used for task 1
let menu = {
    width: 200,
    height: 300,
    title: "My menu"
};

// Call the function with the object for task 1
multiplyNumeric(menu);

// The output should be:
// { width: 400, height: 600, title: 'My menu' }

// Task 2: heater object
let heater = {
    // Properties to store temperature values and step
    minTemperature: 0,
    maxTemperature: 0,
    step: 0,
    currentTemperature: 0,

    // Method to read values and set the current temperature
    read() {
        // Read min, max, and step values from the user
        this.minTemperature = parseInt(prompt("Enter the minimum temperature:"));
        this.maxTemperature = parseInt(prompt("Enter the maximum temperature:"));
        this.step = parseInt(prompt("Enter the step value:"));

        // Calculate the midpoint and set as current temperature
        this.currentTemperature = Math.floor((this.minTemperature + this.maxTemperature) / 2);

        // Print the initial values
        console.log(`Read values: Min=${this.minTemperature}, Max=${this.maxTemperature}, Step=${this.step}, Current=${this.currentTemperature}`);

        // Return 'this' to enable method chaining
        return this;
    },

    // Method to increase the current temperature
    up() {
        // Increase the temperature by the step, but do not exceed maxTemperature
        if (this.currentTemperature + this.step <= this.maxTemperature) {
            this.currentTemperature += this.step;
        } else {
            this.currentTemperature = this.maxTemperature;
        }

        // Print the new temperature
        console.log(`Increased temperature: Current=${this.currentTemperature}`);

        // Return 'this' to enable method chaining
        return this;
    },

    // Method to decrease the current temperature
    down() {
        // Decrease the temperature by the step, but do not go below minTemperature
        if (this.currentTemperature - this.step >= this.minTemperature) {
            this.currentTemperature -= this.step;
        } else {
            this.currentTemperature = this.minTemperature;
        }

        // Print the new temperature
        console.log(`Decreased temperature: Current=${this.currentTemperature}`);

        // Return 'this' to enable method chaining
        return this;
    }
};

// Example of method chaining
heater.read().up().up().down();


//Task 3 and Task 4

let user = {
    name: "Smith",
    age: 30,
    sayHi() {
        console.log("Hi, my name is " + this.name);
    }
};

let admin = {
    name: "Bob",
}

admin.sayHi = user.sayHi;

user.sayHi();
admin.sayHi();

let greetGlobal = user.sayHi; // Function reference without context binding
greetGlobal();

let greetUser = user.sayHi.bind(user); // Using function binding to bind sayHi method to user object
greetUser();

//Task 6
let person = {
    _name: "", // Private attribute for name
    _female: false, // Private attribute for female
    _age: 0, // Private attribute for age

    // Getter for name property
    get name() {
        return this._name;
    },

    // Setter for name property
    set name(value) {
        this._name = value;
    },

    // Getter for female property
    get female() {
        return this._female;
    },

    // Setter for female property
    set female(value) {
        this._female = value;
    },

    // Getter for age property
    get age() {
        return this._age;
    },

    // Setter for age property
    set age(value) {
        if (typeof value === 'number' && value > 0) {
            this._age = value;
        } else if (typeof value === 'number' && value <= 0) {
            console.log("Age must be a number greater than 0.");
        } else {
            console.log("Age must be a number.");
        }
    },

    // Method to print a greeting with all properties of the person
    sayHi() {
        if (this._age > 0) {
            console.log(`Hi, my name is ${this._name}, I am ${this._age} years old, and I am ${this._female ? 'female' : 'male'}.`);
        } else if (this._age <= 0) {
            console.log("Age must be a number greater than 0.");
        } else {
            console.log("Age must be a number.");
        }
    }
};

// Testing the setter/getter methods
person.name = "Alice";
person.female = true;
person.age = 30;

person.sayHi(); // Output: Hi, my name is Alice, I am 30 years old, and I am female.

// Trying to set age to a non-numeric value
person.age = "thirty"; // Output: Age must be a number.

// Trying to set age to a negative value
person.age = -10; // Output: Age must be a number greater than 0.
